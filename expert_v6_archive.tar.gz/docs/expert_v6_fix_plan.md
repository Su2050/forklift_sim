# Expert v6 Fix Plan

## Diagnostic Summary (60 ep, seeds: 0/42/99999)

- steer_sat>=20 steps: 80% drift; steer_sat<5 steps: 0% drift => steer saturation is THE cause
- yaw_diverge: failure group 40.5 steps vs medium 17.5 steps => yaw divergence is chain start
- contact while misaligned: 80% ep, 70% contact steps misaligned => Layer 1 confirmed
- drift direction: 58% positive vs 10% negative => systematic bias
- success ep: avg_d=1.87, avg_lat=0.55 => short approach = less drift opportunity

## Drift Chain (dominant failure mode)

1. k_lat corrects lat => steer biased to one side
2. Ackermann steering also changes yaw => yaw worsens (yaw_diverge)
3. Large yaw drives lat reversal => lat crosses zero (overcorrect, 51%)
4. steer saturates (90% ep) => cannot correct => lat monotonic growth (lat_runaway, 82%)
5. Physically stuck on pallet => pushes pallet (stuck, 40%)

## Fix: Layer 1 + Layer 2

### Layer 1: Fork-Aware Distance + Alignment Gating

L1-A: Introduce fork_length=1.87m, dist_to_contact = dist_front - fork_length
- All distance thresholds recalibrated to dist_to_contact
- retreat_dist_thresh: based on dist_to_contact < 0 (already in contact)

L1-B: Alignment gate when dist_to_contact < gate_margin(0.3m)
- If not aligned (|lat|>0.20 or |yaw|>10deg), limit speed to creep(0.15)

### Layer 2: Anti-Saturation + Yaw Priority

L2-A: Speed reduction when steer saturated
- When |raw_steer| > eff_max_steer * 0.90, reduce drive proportionally
- Minimum 30% speed retained

L2-B: Yaw-priority steering gains
- yaw_priority = min(|yaw| / 20deg, 1.0)
- k_lat scaled down by (1 - 0.5*yaw_priority)
- k_yaw scaled up by (1 + 0.3*yaw_priority)

L2-C: Raise max_steer limits
- max_steer_far: 0.65 -> 0.80
- max_steer_near: 0.40 -> 0.45

## Implementation Order (MAE)

v6-A: Layer 1 + L2-C (low risk, direct impact)
v6-B: L2-A + L2-B (controller logic change)
