#!/usr/bin/env python3
"""
Unit tests for expert policy (v6: fork-aware distance + alignment gate).

Tests can run WITHOUT IsaacLab/Isaac Sim — only needs numpy.
Validates: lat_true, dist_to_contact, fork-proximity slowdown, alignment gate,
           retreat logic, steer limits, gain decay, and info dict fields.

Usage:
    PYTHONPATH=forklift_expert_policy_project:$PYTHONPATH python3 -m pytest tests/test_retreat_logic.py -v
    # or without pytest:
    PYTHONPATH=forklift_expert_policy_project:$PYTHONPATH python3 tests/test_retreat_logic.py
"""
import math
import json
import os
import sys
import numpy as np

# ---- Import policy ----
from forklift_expert.expert_policy import ForkliftExpertPolicy, ExpertConfig

# ---- Load specs ----
_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
with open(os.path.join(_BASE, "forklift_expert", "obs_spec.json")) as f:
    OBS_SPEC = json.load(f)
with open(os.path.join(_BASE, "forklift_expert", "action_spec.json")) as f:
    ACTION_SPEC = json.load(f)

FIELDS = OBS_SPEC["fields"]

# pallet_half_depth from ExpertConfig
_HALF_D = ExpertConfig().pallet_half_depth  # 1.08


def _make_obs(
    d_x: float = 3.0,
    d_y: float = 0.0,
    cos_dyaw: float = 1.0,
    sin_dyaw: float = 0.0,
    v_forward: float = 0.0,
    yaw_rate: float = 0.0,
    insert_norm: float = 0.0,
    y_err_obs: float = 0.0,
    yaw_err_obs: float = 0.0,
    lift_pos: float = 0.0,
) -> np.ndarray:
    """Build a 15-D obs vector with specified semantic values."""
    obs = np.zeros(15, dtype=np.float32)
    obs[FIELDS["d_xy_r_x"]] = d_x
    obs[FIELDS["d_xy_r_y"]] = d_y
    obs[FIELDS["cos_dyaw"]] = cos_dyaw
    obs[FIELDS["sin_dyaw"]] = sin_dyaw
    obs[FIELDS["v_forward"]] = v_forward
    obs[FIELDS["yaw_rate"]] = yaw_rate
    obs[FIELDS["insert_norm"]] = insert_norm
    obs[FIELDS["y_err_obs"]] = y_err_obs
    obs[FIELDS["yaw_err_obs"]] = yaw_err_obs
    obs[FIELDS["lift_pos"]] = lift_pos
    return obs


def _make_obs_for_lat(
    lat_desired: float,
    dist_front: float = 2.0,
    dyaw: float = 0.0,
    insert_norm: float = 0.0,
) -> np.ndarray:
    """Helper: build obs that produces a specific lat_true and dist_front.

    When dyaw=0: lat_true = sin(0)*d_x - cos(0)*d_y = -d_y
    So d_y = -lat_desired.
    Also sets y_err_obs consistently (clipped version).
    """
    d_x = dist_front + _HALF_D
    c = math.cos(dyaw)
    s = math.sin(dyaw)
    if abs(c) > 1e-6:
        d_y = (s * d_x - lat_desired) / c
    else:
        d_y = 0.0

    lat_clipped = max(-0.5, min(0.5, lat_desired))
    y_err_obs = lat_clipped / 0.5

    return _make_obs(
        d_x=d_x, d_y=d_y,
        cos_dyaw=c, sin_dyaw=s,
        insert_norm=insert_norm,
        y_err_obs=y_err_obs,
    )


def _make_policy() -> ForkliftExpertPolicy:
    return ForkliftExpertPolicy(OBS_SPEC, ACTION_SPEC, ExpertConfig())


# =====================================================================
# Test Cases
# =====================================================================

def test_case_0_lat_true_computation():
    """Verify lat_true is computed correctly from d_x/d_y/dyaw."""
    policy = _make_policy()

    # Case A: dyaw=0, d_y=-0.3 -> lat_true = +0.3
    obs_a = _make_obs(d_x=2.0, d_y=-0.3, cos_dyaw=1.0, sin_dyaw=0.0, y_err_obs=0.6)
    _, info_a = policy.act(obs_a)
    assert abs(info_a["lat"] - 0.3) < 0.01, f"Expected lat=0.3, got {info_a['lat']:.4f}"
    assert abs(info_a["lat_clipped"] - 0.3) < 0.01

    # Case B: saturated — d_y=-1.2 -> lat_true = +1.2, but lat_clipped = 0.5
    policy.reset()
    obs_b = _make_obs(d_x=2.0, d_y=-1.2, cos_dyaw=1.0, sin_dyaw=0.0, y_err_obs=1.0)
    _, info_b = policy.act(obs_b)
    assert abs(info_b["lat"] - 1.2) < 0.01
    assert abs(info_b["lat_clipped"] - 0.5) < 0.01

    # Case C: with yaw offset (dyaw=30deg)
    policy.reset()
    dyaw = math.radians(30)
    c, s = math.cos(dyaw), math.sin(dyaw)
    obs_c = _make_obs(d_x=2.0, d_y=0.5, cos_dyaw=c, sin_dyaw=s)
    _, info_c = policy.act(obs_c)
    expected = s * 2.0 - c * 0.5
    assert abs(info_c["lat"] - expected) < 0.01

    print(f"  PASS: lat_true computation verified (aligned, saturated, yaw-offset)")


def test_case_1_retreat_steer_direction():
    """lat=+0.5 (right offset) during retreat -> steer should be > 0."""
    policy = _make_policy()
    obs = _make_obs_for_lat(lat_desired=0.5, dist_front=0.8)
    _, info = policy.act(obs)
    assert info["stage"] == "retreat", f"Expected retreat, got {info['stage']}"
    assert info["raw_steer"] > 0, f"Expected positive steer for lat>0, got {info['raw_steer']:.3f}"
    print(f"  PASS: lat=+0.5 -> retreat steer = {info['raw_steer']:.3f} (positive)")


def test_case_2_retreat_steer_proportional():
    """Larger |lat| should produce larger |steer| during retreat.
    v5-B: lat_term = min(|lat|/0.75, 1.0)*0.50, saturates at lat=0.75."""
    # lat=0.49 (just above 0.48 threshold)
    p1 = _make_policy()
    obs_small = _make_obs_for_lat(lat_desired=0.49, dist_front=0.8)
    _, info_small = p1.act(obs_small)

    # lat=0.8 (v5-B: now above sat point 0.75, should be stronger than 0.49)
    p2 = _make_policy()
    obs_large = _make_obs_for_lat(lat_desired=0.8, dist_front=0.8)
    _, info_large = p2.act(obs_large)

    assert info_small["stage"] == "retreat"
    assert info_large["stage"] == "retreat"
    assert abs(info_large["raw_steer"]) > abs(info_small["raw_steer"]), (
        f"|steer|(lat=0.8)={abs(info_large['raw_steer']):.3f} should > "
        f"|steer|(lat=0.49)={abs(info_small['raw_steer']):.3f}"
    )

    # v5-B specific: lat=0.6 vs lat=0.7 should differ (was identical in v5-A)
    p3 = _make_policy()
    obs_06 = _make_obs_for_lat(lat_desired=0.6, dist_front=0.8)
    _, info_06 = p3.act(obs_06)

    p4 = _make_policy()
    obs_07 = _make_obs_for_lat(lat_desired=0.7, dist_front=0.8)
    _, info_07 = p4.act(obs_07)

    assert abs(info_07["raw_steer"]) > abs(info_06["raw_steer"]), (
        f"v5-B: |steer|(lat=0.7)={abs(info_07['raw_steer']):.3f} should > "
        f"|steer|(lat=0.6)={abs(info_06['raw_steer']):.3f} (was equal in v5-A)"
    )
    print(f"  PASS: proportional steer verified; lat=0.6 -> {info_06['raw_steer']:.3f}, "
          f"lat=0.7 -> {info_07['raw_steer']:.3f}, lat=0.8 -> {info_large['raw_steer']:.3f}")


def test_case_3_retreat_exit_on_alignment():
    """Retreat should exit when BOTH lat AND yaw improve sufficiently.
    v5-B: exit requires abs(yaw) < 30deg in addition to lat conditions."""
    policy = _make_policy()

    # Step 1: trigger retreat with lat=0.7, yaw=0 (small), dist_front=0.8
    obs_start = _make_obs_for_lat(lat_desired=0.7, dist_front=0.8)
    _, info = policy.act(obs_start)
    assert info["stage"] == "retreat"
    assert policy._retreat_entry_lat > 0.65

    # Step 2: lat improves to 0.25, dist=1.3, yaw still small (dyaw=0)
    # 0.25 < 0.7*0.6=0.42 OK, 0.25 < 0.40 OK, yaw ~0 < 30deg OK, dist>1.2 OK
    obs_improved = _make_obs_for_lat(lat_desired=0.25, dist_front=1.3)
    _, info2 = policy.act(obs_improved)
    assert info2["stage"] != "retreat", (
        f"Expected exit from retreat (lat+yaw OK), but stage={info2['stage']}"
    )
    assert policy._retreat_exit_reason == "alignment"
    print(f"  PASS: retreat exited (alignment) when lat improved to 0.25 with small yaw")


def test_case_3b_retreat_no_exit_if_yaw_large():
    """v5-B: retreat should NOT exit alignment-early if yaw is still large,
    even when lat has improved enough."""
    policy = _make_policy()
    cfg = policy.cfg

    # Trigger retreat with lat=0.7, yaw=40deg > exit_yaw_max(30deg)
    dyaw_entry = math.radians(40)
    obs_start = _make_obs_for_lat(lat_desired=0.7, dist_front=0.8, dyaw=dyaw_entry)
    _, info = policy.act(obs_start)
    assert info["stage"] == "retreat"

    # lat improves to 0.25, but yaw stays at 40deg
    obs_lat_ok = _make_obs_for_lat(lat_desired=0.25, dist_front=1.3, dyaw=dyaw_entry)
    _, info2 = policy.act(obs_lat_ok)

    # Should still be in retreat because yaw is too large
    assert info2["stage"] == "retreat", (
        f"Should stay in retreat (yaw=40deg > 30deg), but stage={info2['stage']}"
    )
    print(f"  PASS: retreat blocked alignment-exit when yaw=40deg (> 30deg limit)")


def test_case_4_no_false_trigger():
    """lat_true=0.3 (below 0.35 threshold) should NOT trigger retreat.
    v6-fix: retreat_lat_thresh=0.35 (balanced)."""
    policy = _make_policy()
    obs = _make_obs_for_lat(lat_desired=0.3, dist_front=0.5)  # dtc=0, lat=0.3 < 0.35
    _, info = policy.act(obs)
    assert info["stage"] != "retreat", f"lat=0.3 < 0.35 should NOT trigger retreat, got {info['stage']}"
    print(f"  PASS: lat_true=0.3 -> no retreat trigger (stage={info['stage']})")


def test_case_5_cooldown_blocks_retrigger():
    """After retreat ends, cooldown should block immediate re-triggering.
    Also checks retreat_exit_reason."""
    policy = _make_policy()
    cfg = policy.cfg

    # Trigger and run retreat to max_steps
    obs_trigger = _make_obs_for_lat(lat_desired=0.6, dist_front=0.8)
    for i in range(cfg.max_retreat_steps + 5):
        _, info = policy.act(obs_trigger)
        if info["stage"] != "retreat" and i > 0:
            break

    assert policy._retreat_cooldown_remaining > 0
    assert policy._retreat_exit_reason == "max_steps", (
        f"Expected exit reason 'max_steps', got '{policy._retreat_exit_reason}'"
    )

    _, info_after = policy.act(obs_trigger)
    assert info_after["stage"] != "retreat"
    print(f"  PASS: cooldown blocks re-trigger; exit_reason=max_steps")


def test_case_5b_exit_reason_target_dist():
    """retreat_exit_reason should be 'target_dist' when distance reached."""
    policy = _make_policy()
    cfg = policy.cfg

    # Trigger with lat=0.6, dist=0.8
    obs_trigger = _make_obs_for_lat(lat_desired=0.6, dist_front=0.8)
    _, info = policy.act(obs_trigger)
    assert info["stage"] == "retreat"

    # Next step: dist jumps past retreat_target_dist, lat still bad
    # +0.05 margin for float32 round-trip precision loss
    obs_far = _make_obs_for_lat(lat_desired=0.6, dist_front=cfg.retreat_target_dist + 0.05)
    _, info2 = policy.act(obs_far)
    assert info2["stage"] != "retreat"
    assert policy._retreat_exit_reason == "target_dist", (
        f"Expected 'target_dist', got '{policy._retreat_exit_reason}'"
    )
    print(f"  PASS: retreat exit_reason=target_dist when dist >= {cfg.retreat_target_dist}")


def test_case_6_large_lat_triggers_stronger_response():
    """lat_true=1.0 should produce stronger docking steer than lat_true=0.5.
    v6-fix: use dist_front=3.0 (dtc=1.13 > retreat_dist_thresh=0.30) to stay in docking."""
    p1 = _make_policy()
    obs_v4max = _make_obs_for_lat(lat_desired=0.5, dist_front=3.0)  # dtc=1.13
    _, info_v4 = p1.act(obs_v4max)

    p2 = _make_policy()
    obs_v5 = _make_obs_for_lat(lat_desired=1.0, dist_front=3.0)  # dtc=1.13
    _, info_v5 = p2.act(obs_v5)

    assert info_v4["stage"] == "docking", f"Expected docking, got {info_v4['stage']}"
    assert info_v5["stage"] == "docking", f"Expected docking, got {info_v5['stage']}"
    assert abs(info_v5["raw_steer"]) > abs(info_v4["raw_steer"])
    print(f"  PASS: steer(lat=1.0)={info_v5['raw_steer']:.3f} > steer(lat=0.5)={info_v4['raw_steer']:.3f}")


def test_case_7_retreat_rate_limit_skip():
    """v5-B: first retreat step should skip steer rate_limit (no ramp-up)."""
    policy = _make_policy()

    # Pre-condition: _prev_steer = 0 (fresh policy)
    assert policy._prev_steer == 0.0

    # Trigger retreat with lat=0.7 -> raw_steer should be significant
    obs = _make_obs_for_lat(lat_desired=0.7, dist_front=0.8)
    _, info = policy.act(obs)
    assert info["stage"] == "retreat"

    # With rate_limit skip, the actual steer should == raw_steer
    # (no 0.35/step ramp-up from 0)
    assert abs(info["steer"] - info["raw_steer"]) < 0.01, (
        f"First retreat step should skip rate_limit: steer={info['steer']:.3f} "
        f"should == raw_steer={info['raw_steer']:.3f}"
    )
    print(f"  PASS: first retreat step steer={info['steer']:.3f} == raw_steer={info['raw_steer']:.3f} (no ramp)")


def test_case_8_retreat_lat_sat_parameterised():
    """v5-B: verify retreat lat_term uses retreat_lat_sat=0.75 parameterisation.
    lat=0.375 -> lat_term = 0.375/0.75*0.50 = 0.25
    lat=0.75  -> lat_term = 1.0*0.50 = 0.50 (saturated)
    lat=1.0   -> lat_term = 1.0*0.50 = 0.50 (still saturated)"""
    cfg = ExpertConfig()

    # Compute expected values manually
    for lat_val, expected_term in [(0.375, 0.25), (0.75, 0.50), (1.0, 0.50)]:
        actual = min(lat_val / cfg.retreat_lat_sat, 1.0) * cfg.retreat_steer_gain
        assert abs(actual - expected_term) < 0.001, (
            f"lat={lat_val}: expected lat_term={expected_term}, got {actual:.4f}"
        )

    print(f"  PASS: retreat_lat_sat parameterisation verified (0.375->0.25, 0.75->0.50, 1.0->0.50)")


def test_case_9_lat_dependent_steer_bonus():
    """v5-C + v6: large |lat| should allow stronger docking steer via bonus.
    v6 fix: steer limits use dist_front (not dtc).
    Need dist_front=2.5 (>2.0) to be in 'far' zone.
    max_steer_far = 0.80 (v6).
    lat=0.3 -> no bonus (below 0.4 threshold), steer unchanged
    lat=0.8 -> bonus=min(0.4*0.2, 0.10)=0.08, eff_max_steer=0.80+0.08=0.88
    lat=1.5 -> bonus=min(1.1*0.2, 0.10)=0.10, eff_max_steer=0.90 (capped)"""
    # Small lat: no bonus, steer same as before
    p1 = _make_policy()
    obs_small = _make_obs_for_lat(lat_desired=0.3, dist_front=2.5)  # dist>2.0 → far zone
    _, info_small = p1.act(obs_small)
    assert abs(info_small["raw_steer"]) <= 0.80 + 0.01, (
        f"Small lat should not get bonus: raw_steer={info_small['raw_steer']:.3f}"
    )

    # Large lat: should get bonus and produce stronger steer
    p2 = _make_policy()
    obs_large = _make_obs_for_lat(lat_desired=0.8, dist_front=2.5)  # dist>2.0 → far zone
    _, info_large = p2.act(obs_large)
    assert abs(info_large["raw_steer"]) > 0.80, (
        f"Large lat (0.8) should get bonus: raw_steer={info_large['raw_steer']:.3f} should > 0.80"
    )
    assert abs(info_large["raw_steer"]) <= 0.90 + 0.01, (
        f"Bonus should be capped: raw_steer={info_large['raw_steer']:.3f} should <= 0.90"
    )

    # Very large lat: capped at max bonus
    p3 = _make_policy()
    obs_huge = _make_obs_for_lat(lat_desired=1.5, dist_front=2.5)
    _, info_huge = p3.act(obs_huge)
    assert abs(info_huge["raw_steer"]) <= 0.90 + 0.01

    # Near-distance: no bonus even with large lat (dist < 0.8)
    # Use lat=0.3 to avoid retreat trigger (lat < 0.48)
    p4 = _make_policy()
    obs_near = _make_obs_for_lat(lat_desired=0.3, dist_front=0.5)  # dist < 0.8
    _, info_near = p4.act(obs_near)
    # Near: max_steer_near=0.45 (v6), no bonus (dist<0.8), plus gain decay
    assert abs(info_near["raw_steer"]) <= 0.45 + 0.01, (
        f"Near-distance should not get bonus: raw_steer={info_near['raw_steer']:.3f}"
    )

    print(f"  PASS: lat-dependent bonus verified: small(0.3)={info_small['raw_steer']:.3f}, "
          f"large(0.8)={info_large['raw_steer']:.3f}, huge(1.5)={info_huge['raw_steer']:.3f}, "
          f"near(0.3,d=0.5)={info_near['raw_steer']:.3f}")


# =====================================================================
# v6 Test Cases
# =====================================================================

def test_case_10_dist_to_contact():
    """v6: verify dist_to_contact = max(dist_front - fork_length, 0)."""
    policy = _make_policy()
    cfg = policy.cfg

    # Case A: dist_front=4.0 → dtc = 4.0 - 1.87 = 2.13
    obs_far = _make_obs_for_lat(lat_desired=0.1, dist_front=4.0)
    _, info_far = policy.act(obs_far)
    expected_dtc = 4.0 - cfg.fork_length
    assert abs(info_far["dist_to_contact"] - expected_dtc) < 0.01, (
        f"dtc expected {expected_dtc:.2f}, got {info_far['dist_to_contact']:.2f}"
    )

    # Case B: dist_front=1.0 → dtc = max(1.0 - 1.87, 0) = 0
    policy.reset()
    obs_near = _make_obs_for_lat(lat_desired=0.1, dist_front=1.0)
    _, info_near = policy.act(obs_near)
    assert info_near["dist_to_contact"] == 0.0, (
        f"dtc should be 0 when dist_front < fork_length, got {info_near['dist_to_contact']:.4f}"
    )

    # Case C: dist_front=2.0 → dtc = 2.0 - 1.87 = 0.13
    policy.reset()
    obs_mid = _make_obs_for_lat(lat_desired=0.1, dist_front=2.0)
    _, info_mid = policy.act(obs_mid)
    assert abs(info_mid["dist_to_contact"] - 0.13) < 0.01

    print(f"  PASS: dist_to_contact verified: far={info_far['dist_to_contact']:.2f}, "
          f"near={info_near['dist_to_contact']:.2f}, mid={info_mid['dist_to_contact']:.2f}")


def test_case_11_fork_proximity_slowdown():
    """v6: fork-proximity should reduce docking speed when dtc < fork_slow_dist."""
    cfg = ExpertConfig()

    # Far case: dtc=2.13 > fork_slow_dist(1.0) → no fork slowdown
    p_far = _make_policy()
    obs_far = _make_obs_for_lat(lat_desired=0.05, dist_front=4.0)  # dtc=2.13
    _, info_far = p_far.act(obs_far)
    drive_far = info_far["drive"]

    # Near case: dtc=0.13 < fork_slow_dist(1.0) → fork slowdown active
    p_near = _make_policy()
    obs_near = _make_obs_for_lat(lat_desired=0.05, dist_front=2.0)  # dtc=0.13
    _, info_near = p_near.act(obs_near)
    drive_near = info_near["drive"]

    # Near should be significantly slower due to fork_slow
    # fork_slow = max(0.13/1.0, 0.20) = 0.20, so ~20% of base speed
    assert drive_near < drive_far * 0.5, (
        f"Fork-proximity should cut speed: drive_near={drive_near:.3f} "
        f"should be < 50% of drive_far={drive_far:.3f}"
    )

    assert info_near["stage"] == "docking"
    assert info_far["stage"] == "docking"
    print(f"  PASS: fork-proximity slowdown: far drive={drive_far:.3f}, near drive={drive_near:.3f}")


def test_case_12_alignment_gate_blocks_drive():
    """v6: when dtc < gate_margin and not aligned, gate caps drive.
    gate_lat_ok=0.25, retreat_lat_thresh=0.35.
    Test gate with lat=0.30 (> gate_lat_ok=0.25 but < retreat_lat_thresh=0.35)."""
    cfg = ExpertConfig()

    # Misaligned in gate zone but below retreat threshold:
    # dtc ≈ 0, lat=0.30 (> gate_lat_ok=0.25, < retreat_lat_thresh=0.35)
    p1 = _make_policy()
    obs_mis = _make_obs_for_lat(lat_desired=0.30, dist_front=1.5)  # dtc=0
    _, info_mis = p1.act(obs_mis)
    assert info_mis["stage"] == "docking", (
        f"lat=0.30 < retreat_thresh=0.35 → should be docking, got {info_mis['stage']}"
    )
    # Gate caps drive at gate_creep_speed
    assert info_mis["drive"] <= cfg.gate_creep_speed + 0.01, (
        f"Misaligned in gate: drive={info_mis['drive']:.3f} should <= {cfg.gate_creep_speed}"
    )

    # Aligned in gate zone: dtc ≈ 0, lat=0.10 (< gate_lat_ok=0.25), yaw ≈ 0
    p2 = _make_policy()
    obs_ok = _make_obs_for_lat(lat_desired=0.10, dist_front=1.5)  # dtc=0
    _, info_ok = p2.act(obs_ok)
    assert info_ok["stage"] == "docking"

    print(f"  PASS: alignment gate: misaligned(0.30) drive={info_mis['drive']:.3f} "
          f"(<= {cfg.gate_creep_speed}), aligned(0.10) drive={info_ok['drive']:.3f}")


def test_case_13_v6_info_fields():
    """v6: verify new fields in info dict (dist_to_contact, raw_steer_unclamped,
    eff_max_steer, gain_scale)."""
    policy = _make_policy()
    obs = _make_obs_for_lat(lat_desired=0.2, dist_front=3.0)  # dtc=1.13
    _, info = policy.act(obs)

    required_fields = [
        "dist_to_contact", "raw_steer_unclamped", "eff_max_steer", "gain_scale",
    ]
    for field in required_fields:
        assert field in info, f"Missing v6 info field: {field}"

    # dtc should be float
    assert isinstance(info["dist_to_contact"], float)
    # gain_scale should be between 0.4 and 1.0
    assert 0.4 <= info["gain_scale"] <= 1.0
    # eff_max_steer should be between max_steer_near and max_steer_far + bonus
    assert info["eff_max_steer"] >= ExpertConfig().max_steer_near - 0.01

    print(f"  PASS: v6 info fields present: dtc={info['dist_to_contact']:.2f}, "
          f"eff_max_steer={info['eff_max_steer']:.2f}, gain_scale={info['gain_scale']:.2f}")


def test_case_14_retreat_trigger_uses_dtc():
    """v6: retreat should trigger based on dist_to_contact, not dist_front.
    retreat_dist_thresh=0.30 matches gate_margin (no dead zone).
    dist_front=2.0 → dtc=0.13 < 0.30 → retreat CAN trigger.
    dist_front=3.0 → dtc=1.13 > 0.30 → retreat should NOT trigger."""
    cfg = ExpertConfig()

    # dtc=0.0 < 0.30 → retreat CAN trigger (if lat/yaw conditions met)
    p1 = _make_policy()
    obs_close = _make_obs_for_lat(lat_desired=0.6, dist_front=0.8)  # dtc=0
    _, info_close = p1.act(obs_close)
    assert info_close["stage"] == "retreat", (
        f"dtc=0 + large lat → should retreat, got {info_close['stage']}"
    )

    # dtc=1.13 > 0.30 → retreat should NOT trigger even with large lat
    p2 = _make_policy()
    obs_dtc_far = _make_obs_for_lat(lat_desired=0.6, dist_front=3.0)  # dtc=1.13
    _, info_dtc_far = p2.act(obs_dtc_far)
    assert info_dtc_far["stage"] != "retreat", (
        f"dtc=1.13 > 0.30 → should NOT retreat, got {info_dtc_far['stage']}"
    )

    print(f"  PASS: retreat trigger uses dtc: dtc=0→retreat={info_close['stage']}, "
          f"dtc=1.13→{info_dtc_far['stage']}")


def test_case_15_yaw_priority_steering():
    """v6-B L2-B: yaw-priority reduces effective k_lat and boosts k_yaw
    when |yaw| is large. This should change the steer balance."""
    cfg = ExpertConfig()

    # Small yaw (0deg): yaw_priority = 0 → eff_k_lat = k_lat, eff_k_yaw = k_yaw
    p1 = _make_policy()
    obs_small_yaw = _make_obs_for_lat(lat_desired=0.3, dist_front=4.0, dyaw=0.0)
    _, info_sy = p1.act(obs_small_yaw)
    assert abs(info_sy["eff_k_lat"] - cfg.k_lat) < 0.01, (
        f"Zero yaw: eff_k_lat={info_sy['eff_k_lat']:.3f} should == {cfg.k_lat}"
    )

    # Large yaw (20deg = yaw_priority_angle): yaw_priority = 1.0
    # → eff_k_lat = k_lat * (1 - 0.50) = 0.55
    # → eff_k_yaw = k_yaw * (1 + 0.30) = 1.17
    p2 = _make_policy()
    dyaw_large = math.radians(20.0)
    obs_large_yaw = _make_obs_for_lat(lat_desired=0.3, dist_front=4.0, dyaw=dyaw_large)
    _, info_ly = p2.act(obs_large_yaw)
    expected_k_lat = cfg.k_lat * (1.0 - cfg.yaw_priority_lat_reduce)
    expected_k_yaw = cfg.k_yaw * (1.0 + cfg.yaw_priority_yaw_boost)
    assert abs(info_ly["eff_k_lat"] - expected_k_lat) < 0.01, (
        f"Large yaw: eff_k_lat={info_ly['eff_k_lat']:.3f} should ≈ {expected_k_lat:.3f}"
    )
    assert abs(info_ly["eff_k_yaw"] - expected_k_yaw) < 0.01, (
        f"Large yaw: eff_k_yaw={info_ly['eff_k_yaw']:.3f} should ≈ {expected_k_yaw:.3f}"
    )
    assert info_ly["yaw_priority"] > 0.95

    print(f"  PASS: yaw_priority: small_yaw k_lat={info_sy['eff_k_lat']:.2f}, "
          f"large_yaw k_lat={info_ly['eff_k_lat']:.2f}, k_yaw={info_ly['eff_k_yaw']:.2f}")


def test_case_16_anti_saturation_speed_reduction():
    """v6-B L2-A: when steer is saturated, docking drive should be reduced."""
    cfg = ExpertConfig()

    # Non-saturated: small lat → steer not saturated → drive unaffected
    p1 = _make_policy()
    obs_no_sat = _make_obs_for_lat(lat_desired=0.1, dist_front=4.0)  # dtc=2.13
    _, info_ns = p1.act(obs_no_sat)
    drive_no_sat = info_ns["drive"]

    # Saturated: large lat → steer saturated → drive reduced
    p2 = _make_policy()
    obs_sat = _make_obs_for_lat(lat_desired=1.5, dist_front=4.0)  # dtc=2.13
    _, info_sat = p2.act(obs_sat)
    drive_sat = info_sat["drive"]

    assert info_ns["stage"] == "docking"
    assert info_sat["stage"] == "docking"

    # Saturated case should have lower drive
    assert drive_sat < drive_no_sat, (
        f"Saturated drive={drive_sat:.3f} should be < non-sat drive={drive_no_sat:.3f}"
    )
    # But not below min factor of base drive
    assert drive_sat > 0.0, f"Saturated drive should still be positive"

    # Verify steer IS actually saturated
    assert abs(info_sat["raw_steer_unclamped"]) > abs(info_sat["raw_steer"]) + 0.01, (
        f"Should be saturated: unclamped={info_sat['raw_steer_unclamped']:.3f}, "
        f"clamped={info_sat['raw_steer']:.3f}"
    )

    print(f"  PASS: anti-saturation: no_sat drive={drive_no_sat:.3f}, "
          f"sat drive={drive_sat:.3f} (reduced)")


def test_case_17_v6b_info_fields():
    """v6-B: verify new fields in info dict (yaw_priority, eff_k_lat, eff_k_yaw)."""
    policy = _make_policy()
    obs = _make_obs_for_lat(lat_desired=0.2, dist_front=3.0)
    _, info = policy.act(obs)

    v6b_fields = ["yaw_priority", "eff_k_lat", "eff_k_yaw"]
    for field in v6b_fields:
        assert field in info, f"Missing v6-B info field: {field}"

    assert 0.0 <= info["yaw_priority"] <= 1.0
    assert info["eff_k_lat"] > 0
    assert info["eff_k_yaw"] > 0

    print(f"  PASS: v6-B info fields: yaw_priority={info['yaw_priority']:.2f}, "
          f"eff_k_lat={info['eff_k_lat']:.2f}, eff_k_yaw={info['eff_k_yaw']:.2f}")


# =====================================================================
# Main (fallback for no-pytest environments)
# =====================================================================
def main():
    tests = [
        test_case_0_lat_true_computation,
        test_case_1_retreat_steer_direction,
        test_case_2_retreat_steer_proportional,
        test_case_3_retreat_exit_on_alignment,
        test_case_3b_retreat_no_exit_if_yaw_large,
        test_case_4_no_false_trigger,
        test_case_5_cooldown_blocks_retrigger,
        test_case_5b_exit_reason_target_dist,
        test_case_6_large_lat_triggers_stronger_response,
        test_case_7_retreat_rate_limit_skip,
        test_case_8_retreat_lat_sat_parameterised,
        test_case_9_lat_dependent_steer_bonus,
        test_case_10_dist_to_contact,
        test_case_11_fork_proximity_slowdown,
        test_case_12_alignment_gate_blocks_drive,
        test_case_13_v6_info_fields,
        test_case_14_retreat_trigger_uses_dtc,
        test_case_15_yaw_priority_steering,
        test_case_16_anti_saturation_speed_reduction,
        test_case_17_v6b_info_fields,
    ]
    passed = 0
    failed = 0
    for t in tests:
        name = t.__name__
        try:
            t()
            passed += 1
            print(f"  [OK] {name}")
        except AssertionError as e:
            failed += 1
            print(f"  [FAIL] {name}: {e}")
        except Exception as e:
            failed += 1
            print(f"  [ERROR] {name}: {type(e).__name__}: {e}")

    print(f"\n{'='*60}")
    print(f"  Results: {passed} passed, {failed} failed, {passed+failed} total")
    print(f"{'='*60}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
