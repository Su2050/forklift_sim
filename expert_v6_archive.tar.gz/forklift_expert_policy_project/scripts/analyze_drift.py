#!/usr/bin/env python3
"""
Drift diagnostic analyser for expert policy v5-BC.

Parses non-quiet play_expert.py log files (step-level lines emitted every
10 sim steps) and computes event-frequency statistics that help identify the
dominant drift / failure mechanism.

Usage
-----
    python3 analyze_drift.py logs/diag_v6/seed_0.log \
                              logs/diag_v6/seed_42.log \
                              logs/diag_v6/seed_99999.log \
                              --output logs/diag_v6/drift_report.txt
"""
from __future__ import annotations

import argparse
import math
import os
import re
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, TextIO, Tuple


# ── Constants (mirror expert_policy.py ExpertConfig defaults) ─────────────
MAX_STEER_FAR = 0.65
MAX_STEER_NEAR = 0.40
FORK_LENGTH = 1.87  # metres (from play_expert fork_offset diagnostic)


# ── Data containers ──────────────────────────────────────────────────────
@dataclass
class StepData:
    step: int
    stage: str
    dist: float
    lat: float
    lat_clip: float
    yaw: float
    ins: float
    drv: float
    steer: float  # 'str' in log
    lft: float
    vf: float
    d_y: float
    done: bool = False


@dataclass
class EpisodeData:
    ep_id: int = -1
    seed_file: str = ""
    steps: List[StepData] = field(default_factory=list)
    # summary fields (from [EP ...] line)
    total_steps: int = 0
    init_d: float = 0.0
    init_lat: float = 0.0
    init_yaw: float = 0.0
    init_dy: float = 0.0
    end_d: float = 0.0
    end_lat: float = 0.0
    end_ins: float = 0.0
    min_lat: float = 999.0
    max_ins: float = 0.0


@dataclass
class EventStats:
    """Accumulates per-episode event counts / durations."""
    lat_zero_crosses: int = 0
    yaw_diverge_segments: int = 0       # segments where |lat| shrinks but |yaw| grows
    yaw_diverge_total_steps: int = 0
    steer_sat_segments: int = 0
    steer_sat_total_steps: int = 0
    steer_sat_max_run: int = 0
    stuck_segments: int = 0
    stuck_total_steps: int = 0
    lat_runaway_segments: int = 0       # steer-sat + |lat| monotonic growth >=10 log-steps
    lat_runaway_total_steps: int = 0
    contact_misaligned_steps: int = 0   # ins > 0 and |lat| > 0.3
    contact_total_steps: int = 0        # ins > 0 (any alignment)


# ── Parsing ──────────────────────────────────────────────────────────────
# step=   0  stage=docking     dist=1.865  lat=0.5853(clip=0.500)  yaw=-0.1629  ins=0.000  drv=0.500  str=-0.350  lft=0.000  vf=0.000  d_y=-1.077
_STEP_RE = re.compile(
    r"step=\s*(\d+)\s+stage=(\S+)\s+"
    r"dist=([\d.]+)\s+lat=([0-9eE.+-]+)\(clip=([0-9eE.+-]+)\)\s+"
    r"yaw=([0-9eE.+-]+)\s+ins=([0-9eE.+-]+)\s+"
    r"drv=([0-9eE.+-]+)\s+str=([0-9eE.+-]+)\s+"
    r"lft=([0-9eE.+-]+)\s+vf=([0-9eE.+-]+)\s+"
    r"d_y=([0-9eE.+-]+)"
)

# [EP   0] 1079 steps  reason=truncated   final_stage=docking  ...
_EP_RE = re.compile(
    r"\[EP\s+(\d+)\]\s+(\d+)\s+steps\s+reason=(\S+)\s+final_stage=(\S+)\s+"
    r"init\(d=([\d.]+)\s+lat=([0-9.\-]+)\s+yaw=([0-9.\-]+)\s+dy=([0-9.\-]+)\)\s+"
    r"end\(d=([\d.]+)\s+lat=([0-9.\-]+)\s+ins=([0-9.]+)\)\s+"
    r"min_lat=([0-9.]+)\s+max_ins=([0-9.]+)"
)


def _eff_max_steer(dist: float) -> float:
    """Reproduce the distance-adaptive steer limit from expert_policy.py."""
    if dist > 2.0:
        return MAX_STEER_FAR
    elif dist < 0.8:
        return MAX_STEER_NEAR
    else:
        t = (dist - 0.8) / 1.2
        return MAX_STEER_NEAR + t * (MAX_STEER_FAR - MAX_STEER_NEAR)


def parse_log(path: str) -> List[EpisodeData]:
    """Parse a single play_expert log file into episodes."""
    episodes: List[EpisodeData] = []
    current_steps: List[StepData] = []
    fname = os.path.basename(path)

    with open(path, "r") as f:
        for line in f:
            line = line.rstrip()

            # Try step-level match
            sm = _STEP_RE.search(line)
            if sm:
                sd = StepData(
                    step=int(sm.group(1)),
                    stage=sm.group(2).strip(),
                    dist=float(sm.group(3)),
                    lat=float(sm.group(4)),
                    lat_clip=float(sm.group(5)),
                    yaw=float(sm.group(6)),
                    ins=float(sm.group(7)),
                    drv=float(sm.group(8)),
                    steer=float(sm.group(9)),
                    lft=float(sm.group(10)),
                    vf=float(sm.group(11)),
                    d_y=float(sm.group(12)),
                    done="*** DONE ***" in line,
                )
                current_steps.append(sd)
                continue

            # Try episode summary match
            em = _EP_RE.search(line)
            if em:
                ep = EpisodeData(
                    ep_id=int(em.group(1)),
                    seed_file=fname,
                    steps=list(current_steps),
                    total_steps=int(em.group(2)),
                    init_d=float(em.group(5)),
                    init_lat=float(em.group(6)),
                    init_yaw=float(em.group(7)),
                    init_dy=float(em.group(8)),
                    end_d=float(em.group(9)),
                    end_lat=float(em.group(10)),
                    end_ins=float(em.group(11)),
                    min_lat=float(em.group(12)),
                    max_ins=float(em.group(13)),
                )
                episodes.append(ep)
                current_steps = []

    return episodes


# ── Event detection ──────────────────────────────────────────────────────
def analyse_episode(ep: EpisodeData) -> EventStats:
    """Detect events within a single episode's step-level trace."""
    ev = EventStats()
    steps = ep.steps
    if len(steps) < 2:
        return ev

    # -- Helpers --
    prev_lat_sign = 1 if steps[0].lat >= 0 else -1

    # Running segment trackers
    in_steer_sat = False
    steer_sat_run = 0
    in_stuck = False
    stuck_run = 0
    in_yaw_div = False
    yaw_div_run = 0
    # For lat_runaway: track monotonic |lat| growth during steer-sat
    lat_runaway_run = 0
    prev_abs_lat_for_runaway = abs(steps[0].lat)

    for i in range(1, len(steps)):
        s = steps[i]
        p = steps[i - 1]

        # ── lat zero-cross ──
        cur_sign = 1 if s.lat >= 0 else -1
        if cur_sign != prev_lat_sign and prev_lat_sign != 0:
            ev.lat_zero_crosses += 1
        prev_lat_sign = cur_sign

        # ── yaw diverge (|lat| shrinking but |yaw| growing) ──
        lat_improving = abs(s.lat) < abs(p.lat) - 0.005
        yaw_worsening = abs(s.yaw) > abs(p.yaw) + 0.005
        if lat_improving and yaw_worsening:
            if not in_yaw_div:
                ev.yaw_diverge_segments += 1
                in_yaw_div = True
                yaw_div_run = 0
            yaw_div_run += 1
            ev.yaw_diverge_total_steps += 1
        else:
            in_yaw_div = False
            yaw_div_run = 0

        # ── steer saturation ──
        eff_ms = _eff_max_steer(s.dist)
        saturated = abs(s.steer) >= eff_ms * 0.95
        if saturated:
            if not in_steer_sat:
                ev.steer_sat_segments += 1
                in_steer_sat = True
                steer_sat_run = 0
                lat_runaway_run = 0
                prev_abs_lat_for_runaway = abs(s.lat)
            steer_sat_run += 1
            ev.steer_sat_total_steps += 1
            ev.steer_sat_max_run = max(ev.steer_sat_max_run, steer_sat_run)

            # lat_runaway: monotonic |lat| growth during steer-sat
            if abs(s.lat) >= prev_abs_lat_for_runaway - 0.001:
                lat_runaway_run += 1
            else:
                lat_runaway_run = 0
            prev_abs_lat_for_runaway = abs(s.lat)

            if lat_runaway_run >= 10:
                # Only count once per segment at the 10-step threshold
                if lat_runaway_run == 10:
                    ev.lat_runaway_segments += 1
                ev.lat_runaway_total_steps += 1
        else:
            in_steer_sat = False
            steer_sat_run = 0
            lat_runaway_run = 0

        # ── stuck (drive >> vf) ──
        is_stuck = s.drv > 0.3 and abs(s.vf) < 0.05
        if is_stuck:
            if not in_stuck:
                ev.stuck_segments += 1
                in_stuck = True
                stuck_run = 0
            stuck_run += 1
            ev.stuck_total_steps += 1
        else:
            in_stuck = False
            stuck_run = 0

        # ── contact while misaligned ──
        if s.ins > 0.0:
            ev.contact_total_steps += 1
            if abs(s.lat) > 0.3:
                ev.contact_misaligned_steps += 1

    return ev


# ── Reporting ────────────────────────────────────────────────────────────
def _pct(n: int, total: int) -> str:
    if total == 0:
        return "N/A"
    return f"{n}/{total} ({n / total * 100:.0f}%)"


def generate_report(all_eps: List[Tuple[EpisodeData, EventStats]], out: TextIO) -> None:
    """Write the diagnostic report."""
    N = len(all_eps)
    if N == 0:
        out.write("No episodes to analyse.\n")
        return

    out.write("=" * 72 + "\n")
    out.write(f"  DRIFT DIAGNOSTIC REPORT  ({N} episodes)\n")
    out.write("=" * 72 + "\n\n")

    # ── 1. Event frequency across all episodes ──
    out.write("--- 1. EVENT FREQUENCY (across all episodes) ---\n\n")

    def _ep_has(attr: str) -> int:
        return sum(1 for _, ev in all_eps if getattr(ev, attr) > 0)

    def _ep_avg(attr: str) -> float:
        vals = [getattr(ev, attr) for _, ev in all_eps if getattr(ev, attr) > 0]
        return sum(vals) / len(vals) if vals else 0.0

    events_table = [
        ("lat_zero_cross", "lat_zero_crosses", "lat_zero_crosses",
         "过度纠偏: lat 跨零"),
        ("yaw_diverge", "yaw_diverge_segments", "yaw_diverge_total_steps",
         "假设1: |lat|↓但|yaw|↑"),
        ("steer_sat", "steer_sat_segments", "steer_sat_total_steps",
         "假设2: 转向饱和"),
        ("stuck", "stuck_segments", "stuck_total_steps",
         "假设3: 推托盘(drv>>vf)"),
        ("lat_runaway", "lat_runaway_segments", "lat_runaway_total_steps",
         "关联: 饱和期间lat失控"),
        ("contact_misaligned", "contact_misaligned_steps", "contact_misaligned_steps",
         "Layer1: ins>0且|lat|>0.3"),
    ]

    out.write(f"  {'Event':<24s} {'EPs with event':>16s}  {'Avg segments/ep':>16s}  "
              f"{'Avg steps(10x)/ep':>18s}  {'Purpose'}\n")
    out.write(f"  {'-'*24} {'-'*16}  {'-'*16}  {'-'*18}  {'-'*30}\n")

    for name, seg_attr, step_attr, purpose in events_table:
        n_eps = _ep_has(seg_attr)
        avg_seg = _ep_avg(seg_attr)
        avg_stp = _ep_avg(step_attr)
        out.write(f"  {name:<24s} {_pct(n_eps, N):>16s}  {avg_seg:>16.1f}  "
                  f"{avg_stp:>18.1f}  {purpose}\n")

    # steer_sat max run
    max_runs = [ev.steer_sat_max_run for _, ev in all_eps if ev.steer_sat_max_run > 0]
    if max_runs:
        out.write(f"\n  steer_sat longest continuous run: "
                  f"mean={sum(max_runs)/len(max_runs):.1f}  "
                  f"max={max(max_runs)}  (x10 = real steps)\n")

    # contact stats
    contact_eps = [(ep, ev) for ep, ev in all_eps if ev.contact_total_steps > 0]
    if contact_eps:
        misaligned_pct = sum(ev.contact_misaligned_steps for _, ev in contact_eps) / \
                         sum(ev.contact_total_steps for _, ev in contact_eps) * 100
        out.write(f"\n  Contact steps where |lat|>0.3: {misaligned_pct:.0f}% of all contact steps\n")

    # ── 2. Lat drift direction ──
    out.write(f"\n--- 2. LAT DRIFT DIRECTION ---\n\n")
    pos = sum(1 for ep, _ in all_eps if ep.end_lat > 0.5)
    neg = sum(1 for ep, _ in all_eps if ep.end_lat < -0.5)
    stable = N - pos - neg
    out.write(f"  end_lat > +0.5 (正向漂): {_pct(pos, N)}\n")
    out.write(f"  end_lat < -0.5 (负向漂): {_pct(neg, N)}\n")
    out.write(f"  |end_lat| <= 0.5 (稳定): {_pct(stable, N)}\n")

    overcorrect = sum(1 for ep, _ in all_eps
                      if abs(ep.end_lat) > 0.5 and ep.init_lat * ep.end_lat < 0)
    same_dir = sum(1 for ep, _ in all_eps
                   if abs(ep.end_lat) > 0.5 and ep.init_lat * ep.end_lat > 0)
    drifted = pos + neg
    if drifted > 0:
        out.write(f"\n  漂移中 同向: {_pct(same_dir, drifted)}  "
                  f"反向(过纠偏): {_pct(overcorrect, drifted)}\n")

    # ── 3. Success vs failure comparison ──
    out.write(f"\n--- 3. SUCCESS vs FAILURE COMPARISON ---\n\n")
    success = [(ep, ev) for ep, ev in all_eps if ep.max_ins >= 0.75]
    failure = [(ep, ev) for ep, ev in all_eps if ep.max_ins < 0.10]
    medium = [(ep, ev) for ep, ev in all_eps if 0.10 <= ep.max_ins < 0.75]

    for label, grp in [("SUCCESS (ins>=0.75)", success),
                        ("MEDIUM (0.1<=ins<0.75)", medium),
                        ("FAILURE (ins<0.1)", failure)]:
        n = len(grp)
        if n == 0:
            out.write(f"  {label}: 0 eps\n")
            continue
        avg_init_d = sum(ep.init_d for ep, _ in grp) / n
        avg_init_lat = sum(abs(ep.init_lat) for ep, _ in grp) / n
        avg_init_yaw = sum(abs(ep.init_yaw) for ep, _ in grp) / n
        avg_zero_cross = sum(ev.lat_zero_crosses for _, ev in grp) / n
        avg_steer_sat = sum(ev.steer_sat_total_steps for _, ev in grp) / n
        avg_stuck = sum(ev.stuck_total_steps for _, ev in grp) / n
        avg_yaw_div = sum(ev.yaw_diverge_total_steps for _, ev in grp) / n
        avg_contact_mis = sum(ev.contact_misaligned_steps for _, ev in grp) / n
        out.write(f"  {label}: {n} eps\n")
        out.write(f"    init: avg_d={avg_init_d:.2f}  avg_|lat|={avg_init_lat:.3f}  "
                  f"avg_|yaw|={math.degrees(avg_init_yaw):.1f}deg\n")
        out.write(f"    events: zero_cross={avg_zero_cross:.1f}  "
                  f"steer_sat_steps={avg_steer_sat:.1f}  "
                  f"stuck_steps={avg_stuck:.1f}  "
                  f"yaw_div_steps={avg_yaw_div:.1f}  "
                  f"contact_misal={avg_contact_mis:.1f}\n")

    # ── 4. Correlation: steer saturation vs end_lat ──
    out.write(f"\n--- 4. STEER SATURATION vs DRIFT ---\n\n")
    high_sat = [(ep, ev) for ep, ev in all_eps if ev.steer_sat_total_steps >= 20]
    low_sat = [(ep, ev) for ep, ev in all_eps if ev.steer_sat_total_steps < 5]
    for label, grp in [("High steer-sat (>=20 log-steps)", high_sat),
                        ("Low steer-sat (<5 log-steps)", low_sat)]:
        n = len(grp)
        if n == 0:
            out.write(f"  {label}: 0 eps\n")
            continue
        avg_end_lat = sum(abs(ep.end_lat) for ep, _ in grp) / n
        avg_ins = sum(ep.max_ins for ep, _ in grp) / n
        n_drift = sum(1 for ep, _ in grp if abs(ep.end_lat) > 0.5)
        out.write(f"  {label}: {n} eps\n")
        out.write(f"    avg_|end_lat|={avg_end_lat:.3f}  avg_max_ins={avg_ins:.3f}  "
                  f"drift_rate={_pct(n_drift, n)}\n")

    # ── 5. Per-seed breakdown ──
    out.write(f"\n--- 5. PER-SEED BREAKDOWN ---\n\n")
    seeds = sorted(set(ep.seed_file for ep, _ in all_eps))
    for seed in seeds:
        grp = [(ep, ev) for ep, ev in all_eps if ep.seed_file == seed]
        n = len(grp)
        avg_ins = sum(ep.max_ins for ep, _ in grp) / n
        n_drift = sum(1 for ep, _ in grp if abs(ep.end_lat) > 0.5)
        n_success = sum(1 for ep, _ in grp if ep.max_ins >= 0.75)
        avg_zc = sum(ev.lat_zero_crosses for _, ev in grp) / n
        avg_sat = sum(ev.steer_sat_total_steps for _, ev in grp) / n
        avg_stuck = sum(ev.stuck_total_steps for _, ev in grp) / n
        avg_runaway = sum(ev.lat_runaway_segments for _, ev in grp) / n
        out.write(f"  {seed}:  {n} eps  avg_ins={avg_ins:.3f}  "
                  f"drift={_pct(n_drift, n)}  success={n_success}  "
                  f"avg_zero_cross={avg_zc:.1f}  avg_sat_steps={avg_sat:.1f}  "
                  f"avg_stuck={avg_stuck:.1f}  avg_runaway_seg={avg_runaway:.1f}\n")

    # ── 6. Worst 10 episodes ──
    out.write(f"\n--- 6. WORST 10 EPISODES (lowest max_ins, with event detail) ---\n\n")
    worst = sorted(all_eps, key=lambda x: x[0].max_ins)[:10]
    for ep, ev in worst:
        out.write(
            f"  {ep.seed_file} EP{ep.ep_id:2d}  "
            f"init(d={ep.init_d:.2f} lat={ep.init_lat:+.3f} "
            f"yaw={ep.init_yaw:+.3f}/{math.degrees(ep.init_yaw):+.1f}deg)  "
            f"max_ins={ep.max_ins:.3f}  end_lat={ep.end_lat:+.3f}\n"
            f"    zero_cross={ev.lat_zero_crosses}  "
            f"yaw_div={ev.yaw_diverge_segments}({ev.yaw_diverge_total_steps}steps)  "
            f"steer_sat={ev.steer_sat_segments}({ev.steer_sat_total_steps}steps,max_run={ev.steer_sat_max_run})  "
            f"stuck={ev.stuck_segments}({ev.stuck_total_steps}steps)  "
            f"runaway={ev.lat_runaway_segments}  "
            f"contact_misal={ev.contact_misaligned_steps}\n"
        )

    # ── 7. Best 5 episodes ──
    out.write(f"\n--- 7. BEST 5 EPISODES (highest max_ins, with event detail) ---\n\n")
    best = sorted(all_eps, key=lambda x: -x[0].max_ins)[:5]
    for ep, ev in best:
        out.write(
            f"  {ep.seed_file} EP{ep.ep_id:2d}  "
            f"init(d={ep.init_d:.2f} lat={ep.init_lat:+.3f} "
            f"yaw={ep.init_yaw:+.3f}/{math.degrees(ep.init_yaw):+.1f}deg)  "
            f"max_ins={ep.max_ins:.3f}  end_lat={ep.end_lat:+.3f}\n"
            f"    zero_cross={ev.lat_zero_crosses}  "
            f"yaw_div={ev.yaw_diverge_segments}({ev.yaw_diverge_total_steps}steps)  "
            f"steer_sat={ev.steer_sat_segments}({ev.steer_sat_total_steps}steps,max_run={ev.steer_sat_max_run})  "
            f"stuck={ev.stuck_segments}({ev.stuck_total_steps}steps)  "
            f"runaway={ev.lat_runaway_segments}  "
            f"contact_misal={ev.contact_misaligned_steps}\n"
        )

    out.write("\n" + "=" * 72 + "\n")
    out.write("  END OF REPORT\n")
    out.write("=" * 72 + "\n")


# ── Main ─────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Drift diagnostic analyser")
    parser.add_argument("logs", nargs="+", help="play_expert log files (non-quiet)")
    parser.add_argument("--output", "-o", type=str, default=None,
                        help="Output report file (default: stdout)")
    args = parser.parse_args()

    all_episodes: List[Tuple[EpisodeData, EventStats]] = []

    for logpath in args.logs:
        if not os.path.isfile(logpath):
            print(f"WARNING: {logpath} not found, skipping.", file=sys.stderr)
            continue
        episodes = parse_log(logpath)
        print(f"Parsed {logpath}: {len(episodes)} episodes, "
              f"{sum(len(ep.steps) for ep in episodes)} step-lines",
              file=sys.stderr)
        for ep in episodes:
            ev = analyse_episode(ep)
            all_episodes.append((ep, ev))

    if not all_episodes:
        print("ERROR: No episodes parsed. Check log file format.", file=sys.stderr)
        sys.exit(1)

    if args.output:
        os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
        with open(args.output, "w") as f:
            generate_report(all_episodes, f)
        print(f"Report written to {args.output}", file=sys.stderr)
        # Also print to stdout
        with open(args.output, "r") as f:
            print(f.read())
    else:
        generate_report(all_episodes, sys.stdout)


if __name__ == "__main__":
    main()
